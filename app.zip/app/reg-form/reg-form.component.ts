import { Component, OnInit } from '@angular/core';
import { FormGroup } from '../../../node_modules/@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-reg-form',
  templateUrl: './reg-form.component.html',
  styleUrls: ['./reg-form.component.css']
})
export class RegFormComponent implements OnInit {
  profileForm: FormGroup;
  createForm() {
    this.profileForm = this.fb.group({
      userName: ['', [Validators.required, Validators.minLength(2)]],
      password: [''],
      firstName: ['', [Validators.required, Validators.minLength(5)]],
      lastName: [''],
      Email: ['', [Validators.required, Validators.pattern("[^ @]*@[^ @]*")]]
    });
  }

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.createForm();
  }

  ngOnInit() {

  }

  regDetails={}; 
  onSubmit() {
    console.warn(this.profileForm.value);
    //   this.http.get('http://localhost:8081/'+this.profileForm.value.userName+'/'+this.profileForm.value.password).subscribe((res)=>{
    //     console.log(res);
    // });

    
this.regDetails = this.profileForm.value; 
this.http.get('http://localhost:8081/'+this.profileForm.value.Email).subscribe((result)=>{ 
  console.log(result);
  if(result[0].cnt>0){   
   alert('email is already exits'); 
  }else{ 
  this.http.post('http://localhost:8081/reg', this.regDetails ).subscribe((res) => {
    console.log(res);
  }); 

  } 

  }); 
  



    

  }





}

