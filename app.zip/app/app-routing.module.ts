import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegFormComponent } from './reg-form/reg-form.component';
import { DashbordComponent } from './dashbord/dashbord.component';

const routes: Routes = [
  {path:'', component:DashbordComponent},
  { path: 'regForm', component: RegFormComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
