import { Component, OnInit } from '@angular/core';
import { FormGroup } from '../../../node_modules/@angular/forms';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  profileForm: FormGroup;
  createForm() {
    this.profileForm = this.fb.group({
      userName: [''],
      password: ['']
    });
  }

  encryptData(data) {

    var dataObject = JSON.stringify(data);
    try {
      return CryptoJS.AES.encrypt(dataObject, 'pass').toString();
    } catch (e) {
      console.log(e);
    }

  }

  decryptData(data) {

    try {
      var bytes = CryptoJS.AES.decrypt(data, 'pass');
      return JSON.parse(CryptoJS.enc.Utf8.stringify(bytes));
    } catch (e) {

      console.log(e);

    }

  }


  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.createForm();
  }

  ngOnInit() {
  
  }

  regForm(){ 
    window.location.href="regForm";
  }

  onSubmit() {
    console.warn(this.profileForm.value);
    //   this.http.get('http://localhost:8081/'+this.profileForm.value.userName+'/'+this.profileForm.value.password).subscribe((res)=>{
    //     console.log(res);
    // });
    var encrypt = {auth: this.encryptData(this.profileForm.value)}
    console.log(encrypt);
    this.http.post('http://localhost:8081/post',encrypt).subscribe((res:any)=>{
        console.log(res);
        if(res.length>0){
          window.location.href = 'https://www.w3schools.com/nodejs/nodejs_mysql_select.asp';
        }else{
          alert('username and password incorrect');
        }
    });

  }

  



}
